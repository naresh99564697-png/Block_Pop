import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import { PALETTE } from './game/shapes';
import {
  N,
  type Board,
  type Piece,
  canPlace,
  anyPieceFits,
  findLines,
  lineCells,
  generatePieces,
  lineScore,
  cellIndex,
} from './game/logic';
import { sfx, setSoundEnabled } from './game/audio';
import { FxCanvas, burst, confetti } from './fx';
import {
  IconPause,
  IconPlay,
  IconSound,
  IconMute,
  IconRestart,
  IconCrown,
  LogoMark,
} from './components/icons';

type Status = 'menu' | 'playing' | 'paused' | 'over';

interface Hover {
  r: number;
  c: number;
  valid: boolean;
}
interface ClearCell {
  id: number;
  r: number;
  c: number;
  color: number;
}
interface Popup {
  id: number;
  x: number;
  y: number;
  text: string;
  cls: string;
}
interface DragInfo {
  idx: number;
  pointerId: number;
  cell: number;
  touch: boolean;
  startX: number;
  startY: number;
  piece: Piece;
}

const BEST_KEY = 'blockpop_best_v1';
const SOUND_KEY = 'blockpop_sound_v1';

const vib = (p: number | number[]) => {
  try {
    navigator.vibrate?.(p);
  } catch {
    /* no haptics available */
  }
};

const grad = (color: number) => {
  const c = PALETTE[color];
  return `linear-gradient(150deg, ${c.light} 0%, ${c.base} 52%, ${c.dark} 100%)`;
};

/* ── tiny presentational piece (used by tray + drag layer) ── */
function PieceView({
  piece,
  cell,
  ghost = false,
}: {
  piece: Piece;
  cell: number | null; // null → tray mode, sizes via CSS var
  ghost?: boolean;
}) {
  const u = (n: number) =>
    cell === null ? `calc(${n} * var(--tcell))` : `${(n * cell).toFixed(2)}px`;
  const col = PALETTE[piece.color];
  return (
    <div className="relative" style={{ width: u(piece.w), height: u(piece.h) }}>
      {piece.cells.map(([r, c], i) => (
        <div
          key={i}
          className={`absolute ${cell === null ? 'blk-flat' : 'blk'}`}
          style={{
            left: u(c + 0.07),
            top: u(r + 0.07),
            width: u(0.86),
            height: u(0.86),
            background: ghost ? col.base : grad(piece.color),
          }}
        />
      ))}
    </div>
  );
}

/* ── ambient rising bubbles ── */
const BUBBLES = [
  { l: 6, s: 34, d: 21, w: 0, col: 5 },
  { l: 16, s: 16, d: 15, w: -3, col: 7 },
  { l: 28, s: 48, d: 26, w: 4, col: 3 },
  { l: 42, s: 20, d: 17, w: -2, col: 2 },
  { l: 55, s: 30, d: 23, w: 3, col: 0 },
  { l: 66, s: 14, d: 13, w: -4, col: 4 },
  { l: 76, s: 42, d: 28, w: 2, col: 6 },
  { l: 87, s: 22, d: 18, w: -3, col: 1 },
  { l: 94, s: 30, d: 24, w: 5, col: 3 },
];

function Bubbles() {
  return (
    <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden" aria-hidden>
      {BUBBLES.map((b, i) => {
        const c = PALETTE[b.col];
        return (
          <span
            key={i}
            className="bubble"
            style={{
              left: `${b.l}%`,
              width: b.s,
              height: b.s,
              animationDuration: `${b.d}s`,
              animationDelay: `${-i * 2.7}s`,
              background: `radial-gradient(circle at 32% 30%, ${c.light}66, ${c.base}1e 72%)`,
              border: `1px solid ${c.base}30`,
              ['--sway' as string]: `${b.w * 14}px`,
              ['--o' as string]: 0.16,
            } as CSSProperties}
          />
        );
      })}
    </div>
  );
}

/* ── how-to icons for the start panel ── */
const HowDrag = () => (
  <svg width="34" height="34" viewBox="0 0 24 24" fill="none">
    <rect x="2.5" y="2.5" width="9" height="9" rx="2.5" fill="#4d96ff" />
    <rect x="4.5" y="4" width="3" height="1.6" rx="0.8" fill="rgba(255,255,255,.45)" />
    <path d="M14 7h6m0 0-2.4-2.4M20 7l-2.4 2.4" stroke="#ffd93d" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
    <rect x="12.5" y="12.5" width="9" height="9" rx="2.5" stroke="#9aa5d8" strokeWidth="1.6" strokeDasharray="3 2.4" />
  </svg>
);
const HowLine = () => (
  <svg width="34" height="34" viewBox="0 0 24 24" fill="none">
    {[0, 1, 2, 3].map((i) => (
      <rect key={i} x={2 + i * 5.2} y="9" width="4.4" height="6.4" rx="1.6"
        fill={['#ff5d73', '#ffd93d', '#6bcb77', '#4d96ff'][i]} />
    ))}
    <path d="M12 2.5v3M5 4.5l1.4 2.2M19 4.5l-1.4 2.2" stroke="#ffd93d" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);
const HowCombo = () => (
  <svg width="34" height="34" viewBox="0 0 24 24" fill="none">
    <path d="M13 2 5 13.5h5L10.5 22 19 10h-5.5z" fill="#ffd93d" stroke="#d3a917" strokeWidth="1" strokeLinejoin="round" />
  </svg>
);

export default function App() {
  /* ── core state ── */
  const [status, setStatus] = useState<Status>('menu');
  const [board, setBoard] = useState<Board>(() => new Uint8Array(N * N));
  const [pieces, setPieces] = useState<(Piece | null)[]>([null, null, null]);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem(BEST_KEY) || '0', 10) || 0;
    } catch {
      return 0;
    }
  });
  const [combo, setCombo] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [drag, setDrag] = useState<{ idx: number; x: number; y: number; cell: number } | null>(null);
  const [hover, setHoverState] = useState<Hover | null>(null);
  const [clearing, setClearing] = useState<ClearCell[]>([]);
  const [popups, setPopups] = useState<Popup[]>([]);
  const [shake, setShake] = useState<{ n: number; big: boolean }>({ n: 0, big: false });
  const [slotShake, setSlotShake] = useState<number | null>(null);
  const [lastPlaced, setLastPlaced] = useState<number[]>([]);
  const [comboFlash, setComboFlash] = useState<{ n: number; k: number } | null>(null);
  const [soundOn, setSoundOn] = useState<boolean>(() => {
    try {
      return localStorage.getItem(SOUND_KEY) !== '0';
    } catch {
      return true;
    }
  });
  const [isNewBest, setIsNewBest] = useState(false);
  const [linesTotal, setLinesTotal] = useState(0);
  const [maxCombo, setMaxCombo] = useState(0);

  /* ── refs (stable plumbing for window pointer listeners) ── */
  const gridRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<DragInfo | null>(null);
  const dragElRef = useRef<HTMLDivElement>(null);
  const hoverRef = useRef<Hover | null>(null);
  const boardRef = useRef(board);
  const uidRef = useRef(0);
  const setsUsedRef = useRef(0);
  const overRef = useRef(false);
  const bestBeatenRef = useRef(false);
  const scoreRef = useRef(0);
  const gameIdRef = useRef(0);

  useEffect(() => {
    boardRef.current = board;
  }, [board]);
  useEffect(() => {
    scoreRef.current = score;
  }, [score]);
  useEffect(() => {
    setSoundEnabled(soundOn);
    try {
      localStorage.setItem(SOUND_KEY, soundOn ? '1' : '0');
    } catch { /* ignore */ }
  }, [soundOn]);

  const setHover = useCallback((h: Hover | null) => {
    const prev = hoverRef.current;
    const same =
      (prev === null && h === null) ||
      (prev !== null && h !== null && prev.r === h.r && prev.c === h.c && prev.valid === h.valid);
    hoverRef.current = h;
    if (!same) setHoverState(h);
  }, []);

  /* ── helpers ── */
  const addPopup = useCallback((x: number, y: number, text: string, cls = '') => {
    const id = ++uidRef.current;
    setPopups((p) => [...p.slice(-5), { id, x, y, text, cls }]);
    window.setTimeout(() => setPopups((p) => p.filter((q) => q.id !== id)), 1050);
  }, []);

  const invalidFeedback = useCallback(
    (idx: number) => {
      sfx.invalid();
      vib([18, 30, 18]);
      setSlotShake(idx);
      window.setTimeout(() => setSlotShake((s) => (s === idx ? null : s)), 380);
    },
    [],
  );
  const invalidRef = useRef(invalidFeedback);
  useEffect(() => {
    invalidRef.current = invalidFeedback;
  }, [invalidFeedback]);

  const endGame = useCallback(
    (finalScore: number, gid: number) => {
      if (overRef.current || gid !== gameIdRef.current) return;
      overRef.current = true;
      setStatus('over');
      sfx.over();
      vib([50, 40, 90]);
      setBest((prev) => {
        if (finalScore > prev) {
          setIsNewBest(true);
          try {
            localStorage.setItem(BEST_KEY, String(finalScore));
          } catch { /* ignore */ }
          window.setTimeout(() => {
            confetti(PALETTE.map((c) => c.base).concat('#ffffff'));
            sfx.best();
          }, 350);
          return finalScore;
        }
        return prev;
      });
    },
    [],
  );
  const endGameRef = useRef(endGame);
  useEffect(() => {
    endGameRef.current = endGame;
  }, [endGame]);

  /* ── placement: the heart of the game ── */
  const place = useCallback(
    (idx: number, r: number, c: number): boolean => {
      const p = pieces[idx];
      const b = boardRef.current;
      if (!p || status !== 'playing' || !canPlace(b, p.cells, r, c)) return false;

      const nb = new Uint8Array(b);
      const placedIdx: number[] = [];
      for (const [dr, dc] of p.cells) {
        const i = cellIndex(r + dr, c + dc);
        nb[i] = p.color + 1;
        placedIdx.push(i);
      }

      const { rows, cols } = findLines(nb);
      const lineCount = rows.length + cols.length;
      let gained = 0;
      let newCombo = 0;
      const newClearing: ClearCell[] = [];

      const grid = gridRef.current;
      const rect = grid?.getBoundingClientRect();
      const cell = rect ? rect.width / N : 0;

      if (lineCount > 0) {
        newCombo = combo + 1;
        gained = lineScore(lineCount, newCombo);
        const cells = lineCells(rows, cols);
        let sr = 0;
        let sc = 0;
        for (const [rr, cc] of cells) {
          const i = cellIndex(rr, cc);
          newClearing.push({ id: ++uidRef.current, r: rr, c: cc, color: nb[i] - 1 });
          nb[i] = 0;
          sr += rr;
          sc += cc;
          if (rect) {
            const col = PALETTE[newClearing[newClearing.length - 1].color];
            burst(
              rect.left + (cc + 0.5) * cell,
              rect.top + (rr + 0.5) * cell,
              [col.base, col.light, '#ffffff'],
              6,
              lineCount >= 2 ? 5 : 3.8,
            );
          }
        }
        sfx.clear(lineCount, newCombo);
        if (newCombo >= 2) sfx.combo(newCombo);
        vib(lineCount >= 2 ? [22, 40, 26] : 18);
        setShake((s) => ({ n: s.n + 1, big: lineCount >= 2 || newCombo >= 2 }));
        setLinesTotal((v) => v + lineCount);
        setMaxCombo((m) => Math.max(m, newCombo));
        setComboFlash({ n: newCombo, k: ++uidRef.current });
        window.setTimeout(() => setComboFlash(null), 1400);
        if (rect && cells.length) {
          const px = ((sc / cells.length + 0.5) / N) * 100;
          const py = ((sr / cells.length + 0.5) / N) * 100;
          addPopup(
            px,
            py,
            `+${gained}`,
            lineCount >= 2 || newCombo >= 2
              ? 'text-3xl text-[#ffd93d] text-outline'
              : 'text-2xl text-white text-outline',
          );
        }
        const ids = newClearing.map((x) => x.id);
        setClearing((prev) => [...prev, ...newClearing]);
        window.setTimeout(
          () => setClearing((prev) => prev.filter((x) => !ids.includes(x.id))),
          520,
        );
      } else {
        sfx.place();
        vib(12);
        if (rect) {
          const cr = r + p.h / 2;
          const cc2 = c + p.w / 2;
          burst(
            rect.left + cc2 * cell,
            rect.top + cr * cell,
            ['#ffffff', PALETTE[p.color].light],
            5,
            1.7,
          );
        }
      }

      const newScore = scoreRef.current + p.cells.length + gained;
      if (!bestBeatenRef.current && best > 0 && newScore > best) {
        bestBeatenRef.current = true;
        addPopup(50, 12, 'NEW BEST!', 'text-2xl text-[#ffd93d] text-outline');
        sfx.best();
      }

      const next: (Piece | null)[] = pieces.map((x, i) => (i === idx ? null : x));
      let finalPieces = next;
      if (next.every((x) => x === null)) {
        setsUsedRef.current += 1;
        finalPieces = generatePieces(nb, Math.min(1, setsUsedRef.current / 20));
      }

      setBoard(nb);
      setPieces(finalPieces);
      setScore(newScore);
      setCombo(newCombo);
      setLastPlaced(placedIdx);
      setSelected(null);

      if (!anyPieceFits(nb, finalPieces)) {
        const gid = gameIdRef.current;
        window.setTimeout(() => endGameRef.current(newScore, gid), 700);
      }
      return true;
    },
    [pieces, status, combo, best, addPopup],
  );
  const placeRef = useRef(place);
  useEffect(() => {
    placeRef.current = place;
  }, [place]);

  /* ── game flow ── */
  const startGame = useCallback(() => {
    sfx.wake();
    sfx.ui();
    const empty = new Uint8Array(N * N);
    setsUsedRef.current = 0;
    overRef.current = false;
    gameIdRef.current += 1;
    bestBeatenRef.current = false;
    dragRef.current = null;
    setBoard(empty);
    setPieces(generatePieces(empty, 0));
    setScore(0);
    setCombo(0);
    setSelected(null);
    setDrag(null);
    setHover(null);
    setClearing([]);
    setPopups([]);
    setLastPlaced([]);
    setComboFlash(null);
    setIsNewBest(false);
    setLinesTotal(0);
    setMaxCombo(0);
    setShake({ n: 0, big: false });
    setStatus('playing');
  }, [setHover]);

  const togglePause = useCallback(() => {
    sfx.ui();
    setStatus((s) => (s === 'playing' ? 'paused' : s === 'paused' ? 'playing' : s));
  }, []);

  /* cancel drag whenever the phase changes */
  useEffect(() => {
    dragRef.current = null;
    setDrag(null);
    setHover(null);
  }, [status, setHover]);

  /* auto-pause when the tab is hidden */
  useEffect(() => {
    const onVis = () => {
      if (document.hidden) setStatus((s) => (s === 'playing' ? 'paused' : s));
    };
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);

  /* ── global pointer listeners (drag pipeline) ── */
  useEffect(() => {
    const liftFor = (d: DragInfo) => (d.touch ? d.cell * 1.7 : d.cell * 0.55);

    const onMove = (e: PointerEvent) => {
      const d = dragRef.current;
      if (!d || e.pointerId !== d.pointerId) return;
      e.preventDefault();
      const lift = liftFor(d);
      const el = dragElRef.current;
      if (el) {
        el.style.left = `${e.clientX}px`;
        el.style.top = `${e.clientY - lift}px`;
      }
      const grid = gridRef.current;
      if (!grid) return;
      const rect = grid.getBoundingClientRect();
      const cell = rect.width / N;
      const px = e.clientX;
      const py = e.clientY - lift;
      const c = Math.round((px - rect.left) / cell - d.piece.w / 2);
      const r = Math.round((py - rect.top) / cell - d.piece.h / 2);
      const inRange = r >= 0 && c >= 0 && r <= N - d.piece.h && c <= N - d.piece.w;
      setHover(
        inRange
          ? { r, c, valid: canPlace(boardRef.current, d.piece.cells, r, c) }
          : null,
      );
    };

    const onUp = (e: PointerEvent) => {
      const d = dragRef.current;
      if (!d || e.pointerId !== d.pointerId) return;
      dragRef.current = null;
      setDrag(null);
      const h = hoverRef.current;
      setHover(null);
      const dist = Math.hypot(e.clientX - d.startX, e.clientY - d.startY);
      if (dist < 8) {
        // it was a tap → select / deselect the piece
        sfx.select();
        setSelected((prev) => (prev === d.idx ? null : d.idx));
        return;
      }
      if (h && h.valid) {
        if (!placeRef.current(d.idx, h.r, h.c)) invalidRef.current(d.idx);
      } else if (h && !h.valid) {
        invalidRef.current(d.idx);
      }
      // dropped off-board → silently returns to tray
    };

    window.addEventListener('pointermove', onMove, { passive: false });
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
    };
  }, [setHover]);

  const onPieceDown = useCallback(
    (e: React.PointerEvent, idx: number) => {
      if (status !== 'playing' || dragRef.current) return;
      const p = pieces[idx];
      const grid = gridRef.current;
      if (!p || !grid) return;
      e.preventDefault();
      sfx.wake();
      sfx.pick();
      vib(8);
      const rect = grid.getBoundingClientRect();
      const cell = rect.width / N;
      const touch = e.pointerType === 'touch';
      dragRef.current = {
        idx,
        pointerId: e.pointerId,
        cell,
        touch,
        startX: e.clientX,
        startY: e.clientY,
        piece: p,
      };
      setSelected(null);
      const lift = touch ? cell * 1.7 : cell * 0.55;
      setDrag({ idx, x: e.clientX, y: e.clientY - lift, cell });
    },
    [status, pieces],
  );

  /* tap-to-place: select a piece, then tap the board */
  const anchorFor = useCallback(
    (p: Piece, clientX: number, clientY: number): Hover | null => {
      const grid = gridRef.current;
      if (!grid) return null;
      const rect = grid.getBoundingClientRect();
      const cell = rect.width / N;
      const tc = Math.floor((clientX - rect.left) / cell);
      const tr = Math.floor((clientY - rect.top) / cell);
      if (tc < 0 || tr < 0 || tc >= N || tr >= N) return null;
      const c = Math.min(Math.max(tc - Math.floor(p.w / 2), 0), N - p.w);
      const r = Math.min(Math.max(tr - Math.floor(p.h / 2), 0), N - p.h);
      return { r, c, valid: canPlace(boardRef.current, p.cells, r, c) };
    },
    [],
  );

  const onGridUp = useCallback(
    (e: React.PointerEvent) => {
      if (dragRef.current || selected === null || status !== 'playing') return;
      const p = pieces[selected];
      if (!p) return;
      const h = anchorFor(p, e.clientX, e.clientY);
      if (!h) return;
      if (h.valid) {
        if (!place(selected, h.r, h.c)) invalidFeedback(selected);
      } else {
        invalidFeedback(selected);
      }
    },
    [selected, status, pieces, anchorFor, place, invalidFeedback],
  );

  const onGridMove = useCallback(
    (e: React.PointerEvent) => {
      if (dragRef.current || selected === null || status !== 'playing') return;
      const p = pieces[selected];
      if (!p) return;
      setHover(anchorFor(p, e.clientX, e.clientY));
    },
    [selected, status, pieces, anchorFor, setHover],
  );

  const onGridLeave = useCallback(() => {
    if (!dragRef.current) setHover(null);
  }, [setHover]);

  /* ── derived render data ── */
  const activePiece: Piece | null = drag
    ? pieces[drag.idx]
    : selected !== null
      ? pieces[selected]
      : null;

  const ghost = useMemo(() => {
    if (!hover || !activePiece) return null;
    const cells = new Set<number>();
    for (const [dr, dc] of activePiece.cells) cells.add(cellIndex(hover.r + dr, hover.c + dc));
    return { cells, color: activePiece.color, valid: hover.valid };
  }, [hover, activePiece]);

  const hintCells = useMemo(() => {
    if (!hover || !hover.valid || !activePiece) return null;
    const sim = new Uint8Array(boardRef.current);
    for (const [dr, dc] of activePiece.cells)
      sim[cellIndex(hover.r + dr, hover.c + dc)] = activePiece.color + 1;
    const { rows, cols } = findLines(sim);
    if (rows.length + cols.length === 0) return null;
    const set = new Set<number>();
    for (const [r, c] of lineCells(rows, cols)) set.add(cellIndex(r, c));
    return set;
  }, [hover, activePiece]);

  const clearingAt = useMemo(() => {
    const m = new Map<number, ClearCell>();
    for (const cc of clearing) m.set(cellIndex(cc.r, cc.c), cc);
    return m;
  }, [clearing]);

  const dragPiece = drag ? pieces[drag.idx] : null;

  /* ── render ── */
  return (
    <div
      className="bg-stage relative h-full w-full select-none overflow-hidden"
      style={{ touchAction: 'none' }}
      onContextMenu={(e) => e.preventDefault()}
    >
      <Bubbles />
      <FxCanvas />

      <div
        className="relative z-10 mx-auto flex h-full w-full max-w-[560px] flex-col px-3"
        style={{ paddingTop: 'max(env(safe-area-inset-top), 10px)' }}
      >
        {/* header */}
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LogoMark size={30} />
            <span className="font-display text-[1.35rem] font-semibold leading-none tracking-tight">
              Block<span className="text-[#ffd93d]">Pop!</span>
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              className="btn-icon"
              aria-label={soundOn ? 'Mute sound' : 'Unmute sound'}
              onClick={() => {
                setSoundOn((s) => !s);
                sfx.wake();
                sfx.ui();
              }}
            >
              {soundOn ? <IconSound /> : <IconMute />}
            </button>
            {(status === 'playing' || status === 'paused') && (
              <button className="btn-icon" aria-label="Pause" onClick={togglePause}>
                {status === 'playing' ? <IconPause /> : <IconPlay />}
              </button>
            )}
            {(status === 'playing' || status === 'paused') && (
              <button
                className="btn-icon"
                aria-label="New game"
                onClick={() => {
                  sfx.ui();
                  startGame();
                }}
              >
                <IconRestart />
              </button>
            )}
          </div>
        </header>

        {/* score row */}
        <div className="mt-2 flex items-end justify-between gap-2">
          <div className="chip min-w-[5.4rem] justify-center">
            <span className="text-[#ffd93d]">
              <IconCrown size={14} />
            </span>
            <span className="font-display text-[0.95rem] text-white">
              {best.toLocaleString()}
            </span>
          </div>
          <div className="flex flex-col items-center leading-none">
            <span className="text-[0.62rem] font-black uppercase tracking-[0.22em] text-[#9aa5d8]">
              Score
            </span>
            <span
              key={score}
              className="score-tick font-display text-[2.4rem] font-bold text-white text-outline"
            >
              {score.toLocaleString()}
            </span>
          </div>
          <div
            className={`chip min-w-[5.4rem] justify-center ${
              combo >= 2 ? 'border-[#ffd93d] text-[#ffd93d]' : ''
            }`}
          >
            <span className="text-[0.62rem] font-black uppercase tracking-widest">Combo</span>
            <span className="font-display text-[0.95rem]">
              ×{Math.min(Math.max(combo, 1), 5)}
            </span>
          </div>
        </div>

        {/* board */}
        <div className="flex min-h-0 flex-1 items-center justify-center py-2">
          <div
            key={shake.n}
            className={`board-frame ${
              shake.n > 0 ? (shake.big ? 'anim-shake-b' : 'anim-shake-s') : ''
            }`}
          >
            <div
              ref={gridRef}
              className="relative grid grid-cols-8 gap-[3px]"
              style={{ width: 'var(--board-w)' }}
              onPointerUp={onGridUp}
              onPointerMove={onGridMove}
              onPointerLeave={onGridLeave}
            >
              {Array.from({ length: N * N }, (_, i) => {
                const v = board[i];
                const cc = clearingAt.get(i);
                const isGhost = ghost?.cells.has(i) ?? false;
                const isHint = hintCells?.has(i) ?? false;
                const wasPlaced = lastPlaced.includes(i);
                return (
                  <div key={i} className="relative aspect-square">
                    <div className="cell-base absolute inset-0" />
                    {isHint && v === 0 && <div className="absolute inset-0 line-hint" />}
                    {v > 0 && (
                      <div
                        className={`blk absolute inset-[5%] ${wasPlaced ? 'pop-in' : ''}`}
                        style={{ background: grad(v - 1) }}
                      />
                    )}
                    {isGhost && (
                      <div
                        className={`absolute inset-[5%] rounded-[24%] ${
                          ghost!.valid ? 'ghost-ok' : 'ghost-bad'
                        }`}
                        style={{
                          background: ghost!.valid
                            ? PALETTE[ghost!.color].base
                            : '#ff4757',
                          boxShadow: ghost!.valid
                            ? 'inset 0 0 0 2px rgba(255,255,255,.55)'
                            : 'inset 0 0 0 2px rgba(255,255,255,.4)',
                        }}
                      />
                    )}
                    {cc && (
                      <div
                        className="blk clearing absolute inset-[5%]"
                        style={{ background: grad(cc.color) }}
                      />
                    )}
                  </div>
                );
              })}

              {/* floating score popups + combo flash (board space) */}
              {popups.map((p) => (
                <div
                  key={p.id}
                  className={`float-up pointer-events-none absolute z-20 font-display font-bold ${p.cls}`}
                  style={{ left: `${p.x}%`, top: `${p.y}%` }}
                >
                  {p.text}
                </div>
              ))}
              {comboFlash && comboFlash.n >= 2 && (
                <div
                  key={comboFlash.k}
                  className="combo-pop pointer-events-none absolute left-1/2 top-1/2 z-20 -translate-x-1/2 -translate-y-1/2 text-center"
                >
                  <div className="font-display text-[clamp(1.6rem,7vw,2.6rem)] font-bold text-[#ffd93d] text-outline">
                    COMBO ×{Math.min(comboFlash.n, 5)}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* tray */}
        <div
          className="flex gap-2"
          style={{ paddingBottom: 'max(env(safe-area-inset-bottom), 12px)' }}
        >
          {pieces.map((p, i) => (
            <div
              key={i}
              className={`flex flex-1 items-center justify-center rounded-[1.25rem] border transition-colors duration-200 ${
                slotShake === i ? 'slot-shake' : ''
              } ${
                selected === i
                  ? 'border-[#ffd93d]/80 bg-[#252e63]'
                  : 'border-[#2c3568] bg-[rgba(18,23,58,0.62)]'
              }`}
              style={{ height: 'clamp(84px, 15dvh, 122px)' }}
            >
              {p ? (
                <div
                  className={`tray-in touch-none transition-all duration-150 ${
                    drag?.idx === i
                      ? 'opacity-0'
                      : selected === i
                        ? '-translate-y-1.5 cursor-grabbing drop-shadow-[0_10px_14px_rgba(0,0,0,0.45)]'
                        : 'cursor-grab hover:-translate-y-1'
                  }`}
                  onPointerDown={(e) => onPieceDown(e, i)}
                >
                  <PieceView piece={p} cell={null} />
                </div>
              ) : (
                <div className="flex gap-1.5 opacity-25">
                  {[0, 1, 2].map((d) => (
                    <span key={d} className="h-1.5 w-1.5 rounded-full bg-[#9aa5d8]" />
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* drag layer */}
      {drag && dragPiece && (
        <div
          ref={dragElRef}
          className="pointer-events-none fixed z-[65] will-change-transform"
          style={{
            left: drag.x,
            top: drag.y,
            transform: 'translate(-50%, -50%)',
            filter: 'drop-shadow(0 14px 18px rgba(0,0,0,0.45))',
          }}
        >
          <PieceView piece={dragPiece} cell={drag.cell} />
        </div>
      )}

      {/* ── overlays ── */}
      {status === 'menu' && (
        <div className="fade-in absolute inset-0 z-40 flex items-center justify-center bg-[rgba(8,10,26,0.72)] p-5 backdrop-blur-[3px]">
          <div className="panel rise-in w-full max-w-[380px] px-6 py-7 text-center">
            <div className="bob mx-auto w-fit">
              <LogoMark size={62} />
            </div>
            <h1 className="font-display mt-3 text-[2.7rem] font-bold leading-none tracking-tight text-outline">
              Block<span className="text-[#ffd93d]">Pop!</span>
            </h1>
            <p className="mt-1.5 text-[0.9rem] font-bold text-[#9aa5d8]">
              Fill lines. Pop blocks. Chain combos.
            </p>

            <div className="mt-5 space-y-3 text-left">
              {[
                { ic: <HowDrag />, t: 'Drag a block onto the board — or tap it, then tap the grid.' },
                { ic: <HowLine />, t: 'Fill any full row or column to blast it away and score.' },
                { ic: <HowCombo />, t: 'Clear lines on consecutive turns to stack a ×5 combo.' },
              ].map((row, i) => (
                <div key={i} className="flex items-center gap-3 rounded-[1rem] bg-[rgba(16,20,46,0.55)] px-3 py-2.5">
                  <span className="shrink-0">{row.ic}</span>
                  <span className="text-[0.82rem] font-bold leading-snug text-[#c6cdf2]">{row.t}</span>
                </div>
              ))}
            </div>

            {best > 0 && (
              <div className="chip mx-auto mt-5">
                <span className="text-[#ffd93d]">
                  <IconCrown size={14} />
                </span>
                Best&nbsp;<span className="font-display text-white">{best.toLocaleString()}</span>
              </div>
            )}

            <button
              className="btn-candy btn-play mt-5 w-full py-3.5 text-[1.35rem] font-semibold"
              onClick={startGame}
            >
              <IconPlay size={20} /> PLAY
            </button>
            <p className="mt-3 text-[0.7rem] font-bold text-[#6c76ad]">
              No timers. No ads. Just blocks.
            </p>
          </div>
        </div>
      )}

      {status === 'paused' && (
        <div className="fade-in absolute inset-0 z-40 flex items-center justify-center bg-[rgba(8,10,26,0.78)] p-5 backdrop-blur-[4px]">
          <div className="panel rise-in w-full max-w-[340px] px-6 py-7 text-center">
            <h2 className="font-display text-[2rem] font-bold text-outline">Paused</h2>
            <p className="mt-1 text-[0.85rem] font-bold text-[#9aa5d8]">
              The blocks will wait for you.
            </p>
            <button className="btn-candy btn-play mt-5 w-full py-3 text-[1.15rem] font-semibold" onClick={togglePause}>
              <IconPlay size={18} /> RESUME
            </button>
            <button
              className="btn-candy mt-3 w-full bg-[linear-gradient(180deg,#3b4595,#2b3270)] py-3 text-[1.05rem] font-semibold shadow-[0_5px_0_#1c2252]"
              onClick={startGame}
            >
              <IconRestart size={18} /> NEW GAME
            </button>
            <button
              className="btn-candy mt-3 w-full bg-[linear-gradient(180deg,#3b4595,#2b3270)] py-3 text-[1.05rem] font-semibold shadow-[0_5px_0_#1c2252]"
              onClick={() => {
                setSoundOn((s) => !s);
                sfx.ui();
              }}
            >
              {soundOn ? <IconSound size={18} /> : <IconMute size={18} />}
              {soundOn ? 'SOUND ON' : 'SOUND OFF'}
            </button>
          </div>
        </div>
      )}

      {status === 'over' && (
        <div className="fade-in absolute inset-0 z-40 flex items-center justify-center bg-[rgba(8,10,26,0.78)] p-5 backdrop-blur-[4px]">
          <div className="panel rise-in w-full max-w-[360px] px-6 py-7 text-center">
            <h2 className="font-display text-[2.3rem] font-bold leading-none text-[#ff5d73] text-outline">
              Game Over
            </h2>
            {isNewBest && (
              <div className="combo-pop mx-auto mt-2 w-fit rounded-full border border-[#ffd93d] bg-[rgba(255,217,61,0.12)] px-4 py-1 font-display text-[0.95rem] font-semibold text-[#ffd93d]">
                ★ NEW BEST SCORE ★
              </div>
            )}
            <div className="mt-4 rounded-[1.2rem] bg-[rgba(16,20,46,0.6)] px-4 py-4">
              <div className="text-[0.62rem] font-black uppercase tracking-[0.25em] text-[#9aa5d8]">
                Final score
              </div>
              <div className="font-display text-[3rem] font-bold leading-tight text-white text-outline">
                {score.toLocaleString()}
              </div>
              <div className="mt-1 flex items-center justify-center gap-4 text-[0.8rem] font-bold text-[#9aa5d8]">
                <span className="inline-flex items-center gap-1">
                  <span className="text-[#ffd93d]"><IconCrown size={13} /></span>
                  Best {best.toLocaleString()}
                </span>
                <span>·</span>
                <span>{linesTotal} lines</span>
                <span>·</span>
                <span>max ×{Math.min(Math.max(maxCombo, 1), 5)}</span>
              </div>
            </div>
            <button className="btn-candy btn-hot mt-5 w-full py-3 text-[1.2rem] font-semibold" onClick={startGame}>
              <IconRestart size={19} /> PLAY AGAIN
            </button>
            <button
              className="btn-candy mt-3 w-full bg-[linear-gradient(180deg,#3b4595,#2b3270)] py-2.5 text-[1rem] font-semibold shadow-[0_5px_0_#1c2252]"
              onClick={() => {
                sfx.ui();
                setStatus('menu');
              }}
            >
              MENU
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
