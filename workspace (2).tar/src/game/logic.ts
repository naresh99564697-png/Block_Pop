// ─── Board logic: collision, line detection, piece generation, game over ───
import { SHAPES, PALETTE, type Cell } from './shapes';

export const N = 8;
export type Board = Uint8Array; // 0 = empty, else colour index + 1

export interface Piece {
  uid: number;
  def: number; // index into SHAPES
  cells: Cell[];
  w: number;
  h: number;
  color: number; // palette index
}

export const cellIndex = (r: number, c: number) => r * N + c;

export function canPlace(b: Board, cells: Cell[], r: number, c: number): boolean {
  for (const [dr, dc] of cells) {
    const rr = r + dr;
    const cc = c + dc;
    if (rr < 0 || cc < 0 || rr >= N || cc >= N) return false;
    if (b[cellIndex(rr, cc)] !== 0) return false;
  }
  return true;
}

export function fitsAnywhere(b: Board, p: { cells: Cell[]; w: number; h: number }): boolean {
  for (let r = 0; r <= N - p.h; r++) {
    for (let c = 0; c <= N - p.w; c++) {
      if (canPlace(b, p.cells, r, c)) return true;
    }
  }
  return false;
}

export function anyPieceFits(b: Board, pieces: (Piece | null)[]): boolean {
  return pieces.some((p) => p !== null && fitsAnywhere(b, p));
}

export function findLines(b: Board): { rows: number[]; cols: number[] } {
  const rows: number[] = [];
  const cols: number[] = [];
  for (let r = 0; r < N; r++) {
    let full = true;
    for (let c = 0; c < N; c++) if (b[cellIndex(r, c)] === 0) { full = false; break; }
    if (full) rows.push(r);
  }
  for (let c = 0; c < N; c++) {
    let full = true;
    for (let r = 0; r < N; r++) if (b[cellIndex(r, c)] === 0) { full = false; break; }
    if (full) cols.push(c);
  }
  return { rows, cols };
}

export function lineCells(rows: number[], cols: number[]): Cell[] {
  const set = new Set<number>();
  for (const r of rows) for (let c = 0; c < N; c++) set.add(cellIndex(r, c));
  for (const c of cols) for (let r = 0; r < N; r++) set.add(cellIndex(r, c));
  return [...set].map((i) => [Math.floor(i / N), i % N] as Cell);
}

let uidCounter = 1;

function weightedPick(t: number): number {
  // Difficulty curve: t = 0 → friendly small pieces, t = 1 → big-piece chaos.
  const mul = (s: 's' | 'm' | 'l') =>
    s === 's' ? 1.2 - 0.45 * t : s === 'm' ? 1 : 0.4 + 0.9 * t;
  let total = 0;
  for (const s of SHAPES) total += s.weight * mul(s.size);
  let roll = Math.random() * total;
  for (let i = 0; i < SHAPES.length; i++) {
    roll -= SHAPES[i].weight * mul(SHAPES[i].size);
    if (roll <= 0) return i;
  }
  return 0;
}

function makePiece(defIdx: number, boardFill: number): Piece {
  const d = SHAPES[defIdx];
  // Early game (sparse board): bias colours/shapes stay, but occasionally swap
  // a huge piece for a friendlier one so runs never start brutally.
  let idx = defIdx;
  if (boardFill < 14 && d.size === 'l' && Math.random() < 0.55) {
    idx = weightedPick(0);
  }
  const s = SHAPES[idx];
  return {
    uid: uidCounter++,
    def: idx,
    cells: s.cells,
    w: s.w,
    h: s.h,
    color: Math.floor(Math.random() * PALETTE.length),
  };
}

/**
 * Roll 3 pieces. Re-rolls (up to 50×) until at least one piece fits somewhere,
 * so the game never hands you an unnecessarily impossible set.
 */
export function generatePieces(b: Board, difficulty: number): Piece[] {
  const fill = b.reduce((n, v) => n + (v ? 1 : 0), 0);
  let out: Piece[] = [];
  for (let attempt = 0; attempt < 50; attempt++) {
    out = [
      makePiece(weightedPick(difficulty), fill),
      makePiece(weightedPick(difficulty), fill),
      makePiece(weightedPick(difficulty), fill),
    ];
    if (out.some((p) => fitsAnywhere(b, p))) return out;
  }
  return out; // genuinely stuck → game over
}

/** 1 line = 100 · n², multiplied by the combo chain (capped ×5). */
export function lineScore(lineCount: number, combo: number): number {
  const mult = Math.min(Math.max(combo, 1), 5);
  return 100 * lineCount * lineCount * mult;
}
