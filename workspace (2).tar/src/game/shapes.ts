// ─── BlockPop! shape catalogue & colour palette ────────────────────────────
export type Cell = [number, number];

export interface ShapeDef {
  cells: Cell[];
  w: number;
  h: number;
  weight: number;
  size: 's' | 'm' | 'l'; // small / medium / large (drives difficulty curve)
}

export interface BlockColor {
  base: string;
  light: string;
  dark: string;
}

export const PALETTE: BlockColor[] = [
  { base: '#ff5d73', light: '#ff98a8', dark: '#c23550' }, // coral red
  { base: '#ff9f45', light: '#ffc381', dark: '#d0731f' }, // orange
  { base: '#ffd93d', light: '#ffe98a', dark: '#d3a917' }, // sunny yellow
  { base: '#6bcb77', light: '#a2e3ab', dark: '#3f9e4d' }, // lime green
  { base: '#38d9c0', light: '#8aeee0', dark: '#179c87' }, // teal
  { base: '#4d96ff', light: '#93bfff', dark: '#2c66c9' }, // sky blue
  { base: '#9b5de5', light: '#c49bf2', dark: '#6d35b0' }, // grape
  { base: '#f15bb5', light: '#f9a0d3', dark: '#c02e88' }, // bubblegum
];

function def(coords: Cell[], weight: number): ShapeDef {
  let w = 0;
  let h = 0;
  for (const [r, c] of coords) {
    if (r + 1 > h) h = r + 1;
    if (c + 1 > w) w = c + 1;
  }
  const n = coords.length;
  return { cells: coords, w, h, weight, size: n <= 3 ? 's' : n <= 4 ? 'm' : 'l' };
}

/**
 * Balanced piece pool. Small pieces are common early so runs start smoothly,
 * large pieces become more likely as difficulty ramps up (see generatePieces).
 */
export const SHAPES: ShapeDef[] = [
  // dots & short lines
  def([[0, 0]], 5),
  def([[0, 0], [0, 1]], 8),
  def([[0, 0], [1, 0]], 8),
  def([[0, 0], [0, 1], [0, 2]], 8),
  def([[0, 0], [1, 0], [2, 0]], 8),
  // long lines (the satisfying ones)
  def([[0, 0], [0, 1], [0, 2], [0, 3]], 6),
  def([[0, 0], [1, 0], [2, 0], [3, 0]], 6),
  def([[0, 0], [0, 1], [0, 2], [0, 3], [0, 4]], 4),
  def([[0, 0], [1, 0], [2, 0], [3, 0], [4, 0]], 4),
  // squares & rectangles
  def([[0, 0], [0, 1], [1, 0], [1, 1]], 8),
  def([[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2]], 4),
  def([[0, 0], [0, 1], [1, 0], [1, 1], [2, 0], [2, 1]], 4),
  def(
    [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]],
    2,
  ),
  // small corners (2×2 L)
  def([[0, 0], [1, 0], [1, 1]], 6),
  def([[0, 1], [1, 0], [1, 1]], 6),
  def([[0, 0], [0, 1], [1, 0]], 6),
  def([[0, 0], [0, 1], [1, 1]], 6),
  // big corners (3×3 L)
  def([[0, 0], [1, 0], [2, 0], [2, 1], [2, 2]], 3),
  def([[0, 0], [0, 1], [0, 2], [1, 0], [2, 0]], 3),
  def([[0, 0], [0, 1], [0, 2], [1, 2], [2, 2]], 3),
  def([[0, 2], [1, 2], [2, 0], [2, 1], [2, 2]], 3),
  // T pieces
  def([[0, 0], [0, 1], [0, 2], [1, 1]], 4),
  def([[0, 1], [1, 0], [1, 1], [1, 2]], 4),
  def([[0, 0], [1, 0], [1, 1], [2, 0]], 4),
  def([[0, 1], [1, 0], [1, 1], [2, 1]], 4),
  // S / Z pieces
  def([[0, 1], [0, 2], [1, 0], [1, 1]], 4),
  def([[0, 0], [1, 0], [1, 1], [2, 1]], 4),
  def([[0, 0], [0, 1], [1, 1], [1, 2]], 4),
  def([[0, 1], [1, 0], [1, 1], [2, 0]], 4),
];
