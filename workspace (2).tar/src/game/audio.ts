// ─── Tiny WebAudio synth: all sounds generated, no assets ──────────────────
let ctx: AudioContext | null = null;
let enabled = true;

export function setSoundEnabled(on: boolean) {
  enabled = on;
}

function ac(): AudioContext | null {
  try {
    if (!ctx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

type Wave = OscillatorType;

function tone(
  f0: number,
  f1: number | null,
  dur: number,
  type: Wave,
  vol: number,
  delay = 0,
) {
  const a = ac();
  if (!a || !enabled) return;
  try {
    const t0 = a.currentTime + delay;
    const o = a.createOscillator();
    const g = a.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t0);
    if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(a.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.05);
  } catch {
    /* audio is decorative – never break the game */
  }
}

export const sfx = {
  wake() {
    ac();
  },
  ui() {
    tone(660, 880, 0.07, 'triangle', 0.12);
  },
  pick() {
    tone(340, 520, 0.07, 'square', 0.08);
  },
  place() {
    tone(220, 150, 0.09, 'triangle', 0.22);
    tone(440, 330, 0.06, 'sine', 0.1, 0.01);
  },
  invalid() {
    tone(170, 90, 0.16, 'sawtooth', 0.14);
  },
  select() {
    tone(520, 700, 0.06, 'sine', 0.1);
  },
  clear(lines: number, combo: number) {
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5];
    const count = Math.min(2 + lines, notes.length);
    const lift = 1 + Math.min(combo - 1, 4) * 0.12;
    for (let i = 0; i < count; i++) {
      tone(notes[i] * lift, notes[i] * lift, 0.14, 'triangle', 0.16, i * 0.055);
    }
    if (lines >= 2) tone(1568 * lift, 2093 * lift, 0.2, 'sine', 0.12, count * 0.055);
  },
  combo(level: number) {
    const f = 700 + Math.min(level, 5) * 120;
    tone(f, f * 1.5, 0.12, 'square', 0.08);
  },
  best() {
    [1046.5, 1318.5, 1568, 2093].forEach((f, i) =>
      tone(f, f, 0.16, 'triangle', 0.12, i * 0.09),
    );
  },
  over() {
    tone(392, 392, 0.18, 'triangle', 0.16, 0);
    tone(311, 311, 0.18, 'triangle', 0.16, 0.16);
    tone(233, 110, 0.5, 'triangle', 0.18, 0.32);
  },
};
