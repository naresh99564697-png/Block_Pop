// ─── Particle FX layer: one full-screen canvas, imperative API ─────────────
import { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  g: number;
  drag: number;
  life: number;
  ttl: number;
  size: number;
  color: string;
  kind: 'dot' | 'rect' | 'spark';
  rot: number;
  vr: number;
}

const parts: Particle[] = [];

function spawn(p: Particle) {
  if (parts.length < 600) parts.push(p);
}

/** Burst of candy shards at viewport coords (x, y). */
export function burst(
  x: number,
  y: number,
  colors: string[],
  n = 12,
  power = 4.2,
) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2;
    const sp = (0.3 + Math.random() * 0.7) * power;
    const kind = Math.random() < 0.4 ? 'rect' : Math.random() < 0.5 ? 'dot' : 'spark';
    spawn({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp - power * 0.35,
      g: 0.14,
      drag: 0.985,
      life: 1,
      ttl: 34 + Math.random() * 26,
      size: kind === 'rect' ? 3 + Math.random() * 5 : 2 + Math.random() * 3.5,
      color: colors[Math.floor(Math.random() * colors.length)],
      kind,
      rot: Math.random() * Math.PI,
      vr: (Math.random() - 0.5) * 0.3,
    });
  }
}

/** Full-screen celebration rain. */
export function confetti(colors: string[]) {
  const w = window.innerWidth;
  for (let i = 0; i < 110; i++) {
    spawn({
      x: Math.random() * w,
      y: -20 - Math.random() * window.innerHeight * 0.4,
      vx: (Math.random() - 0.5) * 2.4,
      vy: 2 + Math.random() * 3.4,
      g: 0.045,
      drag: 0.992,
      life: 1,
      ttl: 110 + Math.random() * 80,
      size: 4 + Math.random() * 6,
      color: colors[Math.floor(Math.random() * colors.length)],
      kind: Math.random() < 0.7 ? 'rect' : 'dot',
      rot: Math.random() * Math.PI,
      vr: (Math.random() - 0.5) * 0.25,
    });
  }
}

export function FxCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let raf = 0;
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(window.innerWidth * dpr);
      canvas.height = Math.floor(window.innerHeight * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const tick = () => {
      raf = requestAnimationFrame(tick);
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      if (parts.length === 0) return;
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i];
        p.life -= 1 / p.ttl;
        if (p.life <= 0) {
          parts.splice(i, 1);
          continue;
        }
        p.vx *= p.drag;
        p.vy = p.vy * p.drag + p.g;
        p.x += p.vx;
        p.y += p.vy;
        p.rot += p.vr;
        ctx.globalAlpha = Math.min(1, p.life * 1.6);
        ctx.fillStyle = p.color;
        if (p.kind === 'dot') {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.kind === 'rect') {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.72);
          ctx.restore();
        } else {
          ctx.strokeStyle = p.color;
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 2.2, p.y - p.vy * 2.2);
          ctx.stroke();
        }
      }
      ctx.globalAlpha = 1;
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      className="pointer-events-none fixed inset-0 z-[70] h-full w-full"
      aria-hidden
    />
  );
}
