// ─── Inline SVG icons (no external assets) ─────────────────────────────────
import type { ReactNode } from 'react';

interface IconProps {
  size?: number;
  className?: string;
}

const S = ({ size = 20, className = '', children }: IconProps & { children: ReactNode }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={2.4}
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    {children}
  </svg>
);

export const IconPause = (p: IconProps) => (
  <S {...p}>
    <line x1="9" y1="5" x2="9" y2="19" />
    <line x1="15" y1="5" x2="15" y2="19" />
  </S>
);

export const IconPlay = (p: IconProps) => (
  <S {...p}>
    <path d="M7 4.5v15l13-7.5z" fill="currentColor" stroke="none" />
  </S>
);

export const IconSound = (p: IconProps) => (
  <S {...p}>
    <path d="M11 5 6.5 9H3v6h3.5L11 19z" fill="currentColor" stroke="none" />
    <path d="M15.5 8.5a5 5 0 0 1 0 7" />
    <path d="M18.5 6a9 9 0 0 1 0 12" />
  </S>
);

export const IconMute = (p: IconProps) => (
  <S {...p}>
    <path d="M11 5 6.5 9H3v6h3.5L11 19z" fill="currentColor" stroke="none" />
    <line x1="15.5" y1="9.5" x2="20.5" y2="14.5" />
    <line x1="20.5" y1="9.5" x2="15.5" y2="14.5" />
  </S>
);

export const IconRestart = (p: IconProps) => (
  <S {...p}>
    <path d="M3.5 8a9 9 0 1 1-1 6" />
    <path d="M3 3v5h5" />
  </S>
);

export const IconCrown = (p: IconProps) => (
  <S {...p}>
    <path
      d="M3 17 2 7l5.5 4L12 4l4.5 7L22 7l-1 10z"
      fill="currentColor"
      stroke="none"
    />
    <rect x="3" y="18.5" width="18" height="2.5" rx="1.2" fill="currentColor" stroke="none" />
  </S>
);

/** Chunky 2×2 block mark used as the logo. */
export const LogoMark = ({ size = 30 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden>
    <rect x="2" y="2" width="17" height="17" rx="5" fill="#ff5d73" />
    <rect x="21" y="2" width="17" height="17" rx="5" fill="#ffd93d" />
    <rect x="2" y="21" width="17" height="17" rx="5" fill="#4d96ff" />
    <rect x="21" y="21" width="17" height="17" rx="8.5" fill="#6bcb77" />
    <rect x="5" y="4.5" width="7" height="4" rx="2" fill="rgba(255,255,255,.4)" />
    <rect x="24" y="4.5" width="7" height="4" rx="2" fill="rgba(255,255,255,.45)" />
    <rect x="5" y="23.5" width="7" height="4" rx="2" fill="rgba(255,255,255,.4)" />
    <rect x="24.5" y="24.5" width="7" height="4" rx="2" fill="rgba(255,255,255,.4)" />
  </svg>
);
